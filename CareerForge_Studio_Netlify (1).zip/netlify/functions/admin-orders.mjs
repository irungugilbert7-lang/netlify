import { json, listOrders, safeEqual } from "../lib/shared.mjs";

export default async (req) => {
  const token = process.env.ADMIN_TOKEN;
  if (!token) return json({ error: "Not found." }, 404);
  const supplied = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!supplied || !safeEqual(supplied, token)) return json({ error: "Unauthorized." }, 401);
  return json({ orders: await listOrders() });
};

export const config = {
  path: "/api/admin/orders",
  method: "GET",
  rateLimit: { windowLimit: 10, windowSize: 60, aggregateBy: ["ip", "domain"] }
};
