import {
  json, clean, readJson, isOrderId, getOrder, saveOrder, linkPaypalOrder,
  paypalAccessToken, paypalApi, CURRENCY
} from "../lib/shared.mjs";

export default async (req) => {
  try {
    const body = await readJson(req);
    const orderId = clean(body?.orderId, 80);
    const order = isOrderId(orderId) ? await getOrder(orderId) : null;
    if (!order) return json({ error: "Order not found. Please submit the order form again." }, 404);
    if (order.status !== "awaiting_payment") return json({ error: "This order is not available for payment." }, 409);

    const origin = new URL(req.url).origin;
    const token = await paypalAccessToken();
    const response = await fetch(`${paypalApi()}/v2/checkout/orders`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [{
          reference_id: order.id,
          custom_id: order.id,
          description: order.packageName,
          amount: { currency_code: CURRENCY, value: order.amount }
        }],
        application_context: {
          brand_name: "CareerForge Studio",
          user_action: "PAY_NOW",
          shipping_preference: "NO_SHIPPING",
          return_url: `${origin}/?payment=success`,
          cancel_url: `${origin}/?payment=cancelled`
        }
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "PayPal could not create the payment.");

    await linkPaypalOrder(data.id, order.id);
    await saveOrder({ ...order, paypalOrderId: data.id, updatedAt: new Date().toISOString() });
    return json({ id: data.id });
  } catch (error) {
    console.error("PayPal create order:", error.message);
    return json({ error: error.message || "Unable to start PayPal checkout." }, 500);
  }
};

export const config = {
  path: "/api/paypal/create-order",
  method: "POST",
  rateLimit: { windowLimit: 15, windowSize: 60, aggregateBy: ["ip", "domain"] }
};
