import { json, clean, readJson, PACKAGES, CURRENCY, newOrderId, saveOrder } from "../lib/shared.mjs";

export default async (req) => {
  const body = await readJson(req);
  if (!body) return json({ error: "Invalid request." }, 400);

  const packageId = clean(body.packageId, 50);
  const pack = Object.hasOwn(PACKAGES, packageId) ? PACKAGES[packageId] : null;
  const name = clean(body.name, 100);
  const email = clean(body.email, 160).toLowerCase();
  const targetRole = clean(body.targetRole, 160);
  const notes = clean(body.notes, 1500);

  if (!pack) return json({ error: "Please select a valid package." }, 400);
  if (name.length < 2) return json({ error: "Please enter your name." }, 400);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Please enter a valid email address." }, 400);
  if (body.consent !== true) return json({ error: "Please agree to the privacy and service terms." }, 400);

  const id = newOrderId();
  await saveOrder({
    id, packageId, packageName: pack.name, amount: pack.price, currency: CURRENCY,
    ...(pack.balance ? { balanceDue: pack.balance } : {}),
    customer: { name, email, targetRole, notes },
    status: "awaiting_payment",
    createdAt: new Date().toISOString()
  });
  return json({ orderId: id, packageName: pack.name, amount: pack.price, currency: CURRENCY }, 201);
};

export const config = {
  path: "/api/orders",
  method: "POST",
  rateLimit: { windowLimit: 15, windowSize: 60, aggregateBy: ["ip", "domain"] }
};
