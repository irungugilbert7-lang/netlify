import { json, PACKAGES, CURRENCY, paypalEnv } from "../lib/shared.mjs";

export default async () =>
  json({
    paypalClientId: process.env.PAYPAL_CLIENT_ID || "",
    currency: CURRENCY,
    paypalEnv: paypalEnv(),
    packages: PACKAGES
  });

export const config = { path: "/api/config", method: "GET" };
