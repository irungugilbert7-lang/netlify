import {
  json, clean, readJson, isPaypalId, findOrderByPaypalId, saveOrder,
  paypalAccessToken, paypalApi, sendPaidNotification, CURRENCY
} from "../lib/shared.mjs";

export default async (req) => {
  try {
    const body = await readJson(req);
    const paypalOrderId = clean(body?.paypalOrderId, 100);
    const order = isPaypalId(paypalOrderId) ? await findOrderByPaypalId(paypalOrderId) : null;
    if (!order) return json({ error: "Matching CareerForge order not found." }, 404);
    if (order.status === "paid") return json({ status: "COMPLETED", orderId: order.id, packageName: order.packageName });

    const token = await paypalAccessToken();
    const response = await fetch(`${paypalApi()}/v2/checkout/orders/${encodeURIComponent(paypalOrderId)}/capture`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "PayPal could not capture the payment.");

    const capture = data.purchase_units?.[0]?.payments?.captures?.[0];
    if (data.status !== "COMPLETED" || !capture ||
        capture.amount?.value !== order.amount || capture.amount?.currency_code !== CURRENCY) {
      throw new Error("Payment was not confirmed for the expected amount. Contact support before retrying.");
    }

    const paid = {
      ...order,
      status: "paid",
      paidAt: new Date().toISOString(),
      paypalCaptureId: capture.id,
      paypalStatus: data.status,
      updatedAt: new Date().toISOString()
    };
    await saveOrder(paid);
    await sendPaidNotification(paid);
    return json({ status: "COMPLETED", orderId: order.id, packageName: order.packageName });
  } catch (error) {
    console.error("PayPal capture:", error.message);
    return json({ error: error.message || "Unable to confirm payment." }, 500);
  }
};

export const config = {
  path: "/api/paypal/capture-order",
  method: "POST",
  rateLimit: { windowLimit: 15, windowSize: 60, aggregateBy: ["ip", "domain"] }
};
