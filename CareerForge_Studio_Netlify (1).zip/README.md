# CareerForge Studio — Netlify deployment

## 1. Upload
Easiest: push this folder to a GitHub repository, then in Netlify choose
**Add new site → Import an existing project** and select the repo.
Settings are read from `netlify.toml` (publish folder `public`, functions in `netlify/functions`). No build command is needed.

(Dragging the folder onto Netlify's manual-deploy box also serves the pages, but the payment functions only work reliably with Git or the Netlify CLI deploy.)

## 2. Environment variables
Site configuration → Environment variables. Add:

| Name | Value |
|---|---|
| PAYPAL_CLIENT_ID | your PayPal app Client ID |
| PAYPAL_CLIENT_SECRET | your PayPal app Secret |
| PAYPAL_ENV | `sandbox` while testing, `live` when ready |
| ORDER_NOTIFICATION_EMAIL | gindrajmahal@gmail.com |
| RESEND_API_KEY | (optional) free key from resend.com for order emails |
| ADMIN_TOKEN | (optional) long random string to view orders |

Mark the Secret, RESEND_API_KEY and ADMIN_TOKEN as secret values. Redeploy after changing variables.

## 3. Test in Sandbox
Visit your Netlify URL, place an order, and pay with a PayPal **Sandbox personal** account.
Then check Netlify → Logs → Functions if anything fails.

## 4. See your orders
- With RESEND_API_KEY set, every paid order is emailed to ORDER_NOTIFICATION_EMAIL (name, email, role, notes).
- Or open orders any time (replace the token):
  `curl -H "Authorization: Bearer YOUR_ADMIN_TOKEN" https://YOUR-SITE.netlify.app/api/admin/orders`
- Orders are stored in Netlify Blobs (site dashboard → Blobs).

## 5. Go live
1. Create a **Live** PayPal app; put its Client ID/Secret in Netlify and set `PAYPAL_ENV=live`.
2. Redeploy, then place one small real order to confirm it works end to end.
3. Have the Service Terms and Privacy Notice reviewed for your business and customers.

## Local testing
`npm install`, copy `.env.example` to `.env`, then `npx netlify dev` (needs internet).
