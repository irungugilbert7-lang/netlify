const packageDetails = {
  cv_essentials: { name: "CV Essentials", amount: "$49.00" },
  career_upgrade: { name: "Career Upgrade", amount: "$99.00" },
  complete_career: { name: "Complete Career Package", amount: "$149.00" },
  white_label_pilot: { name: "White-Label Writing Pilot", amount: "$300.00" }
};

const form = document.getElementById("orderForm");
const packageSelect = document.getElementById("packageId");
const formMessage = document.getElementById("formMessage");
const checkoutPanel = document.getElementById("checkoutPanel");
const paymentMessage = document.getElementById("paymentMessage");
const submitButton = document.getElementById("submitOrder");
let currentOrderId = null;
let paypalLoaded = false;

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("menuToggle").addEventListener("click", () => {
  const nav = document.getElementById("mainNav");
  const open = nav.classList.toggle("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded", String(open));
});
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => {
  document.getElementById("mainNav").classList.remove("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded", "false");
}));

document.querySelectorAll(".choose-package").forEach(button => {
  button.addEventListener("click", () => {
    packageSelect.value = button.dataset.package;
    document.getElementById("order").scrollIntoView({ behavior: "smooth" });
    packageSelect.focus({ preventScroll: true });
  });
});

async function loadPayPal() {
  if (paypalLoaded) return;
  const configResponse = await fetch("/api/config");
  const config = await configResponse.json();
  if (!config.paypalClientId || config.paypalClientId.startsWith("YOUR_")) {
    throw new Error("PayPal is not configured yet. The website owner must add PayPal Developer credentials to the server.");
  }
  await new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(config.paypalClientId)}&currency=USD&intent=capture&enable-funding=card`;
    script.onload = resolve;
    script.onerror = () => reject(new Error("Could not load PayPal checkout. Please try again."));
    document.head.appendChild(script);
  });
  paypalLoaded = true;
}

async function showPayPalButtons() {
  await loadPayPal();
  document.getElementById("paypalButtons").innerHTML = "";
  paypal.Buttons({
    style: { layout: "vertical", shape: "rect", label: "paypal", color: "gold", tagline: false },
    createOrder: async () => {
      const response = await fetch("/api/paypal/create-order", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId: currentOrderId })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not start PayPal checkout.");
      return data.id;
    },
    onApprove: async (data) => {
      paymentMessage.textContent = "Confirming your payment securely…";
      const response = await fetch("/api/paypal/capture-order", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paypalOrderId: data.orderID })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Payment confirmation failed.");
      paymentMessage.className = "message success";
      paymentMessage.textContent = `Payment confirmed. Your ${result.packageName} order is recorded. We will contact you using the email you provided.`;
      document.getElementById("paypalButtons").style.display = "none";
    },
    onCancel: () => {
      paymentMessage.textContent = "Checkout was cancelled. Your order details are saved; you can try again.";
    },
    onError: (err) => {
      console.error(err);
      paymentMessage.textContent = err.message || "A payment error occurred. Please try again or contact us.";
    }
  }).render("#paypalButtons");
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  formMessage.textContent = "";
  const formData = new FormData(form);
  const payload = {
    packageId: formData.get("packageId"),
    name: formData.get("name"),
    email: formData.get("email"),
    targetRole: formData.get("targetRole"),
    notes: formData.get("notes"),
    consent: document.getElementById("consent").checked
  };
  submitButton.disabled = true;
  submitButton.textContent = "Submitting…";
  try {
    const response = await fetch("/api/orders", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Could not submit your order.");
    currentOrderId = result.orderId;
    document.getElementById("checkoutPackage").textContent = result.packageName;
    document.getElementById("checkoutAmount").textContent = `$${Number(result.amount).toFixed(2)} USD`;
    form.hidden = true;
    checkoutPanel.hidden = false;
    try { await showPayPalButtons(); }
    catch (error) { paymentMessage.textContent = error.message; }
  } catch (error) {
    formMessage.textContent = error.message;
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = 'Continue to payment <span>→</span>';
  }
});

document.getElementById("editOrder").addEventListener("click", () => {
  checkoutPanel.hidden = true;
  form.hidden = false;
  paymentMessage.textContent = "";
  document.getElementById("paypalButtons").style.display = "block";
});

const params = new URLSearchParams(location.search);
if (params.get("payment") === "cancelled") {
  document.getElementById("order").scrollIntoView();
  document.getElementById("formMessage").textContent = "Checkout was cancelled. You can submit your order and try again.";
}
